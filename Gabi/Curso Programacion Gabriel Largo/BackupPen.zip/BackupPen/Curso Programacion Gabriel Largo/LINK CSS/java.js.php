$(".dropdown").click(function () {
  $(".dropdown-content").toggle();
});